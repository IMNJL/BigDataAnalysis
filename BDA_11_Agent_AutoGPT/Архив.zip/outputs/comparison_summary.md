# Comparison summary
## High-level metrics
- Auto report word count: 98
- Manual report word count: 39

## Numeric stats comparison
- **_detected_columns**: auto={'survived': '2urvived', 'sex': 'Sex', 'age': 'Age', 'pclass': 'Pclass'} | manual=None
- **age_mean**: auto=29.50318563789152 | manual=None
- **age_median**: auto=28.0 | manual=None
- **n_rows**: auto=1309 | manual=1309
- **survival_by_pclass**: auto={'1': 0.42105263157894735, '2': 0.3140794223826715, '3': 0.16784203102961917} | manual=None
- **survival_by_sex**: auto={'0': 0.12930011862396204, '1': 0.5} | manual={'0': 0.12930011862396204, '1': 0.5}
- **survival_rate**: auto=0.2612681436210848 | manual=0.2612681436210848

## Interpretation
- Survival rate difference: 0.000000
- Numbers match closely (within floating noise).