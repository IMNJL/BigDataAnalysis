# Auto Agent Report




## Plan executed




1. Load dataset

2. Clean / inspect missing values

3. Compute descriptive statistics

4. Plot survival by sex

5. Plot age distribution by survival

6. Summarize findings and write report




## Key statistics




- **n_rows**: 1309

- **survival_rate**: 0.2612681436210848

- **survival_by_sex**: {0: 0.12930011862396204, 1: 0.5}

- **age_mean**: 29.50318563789152

- **age_median**: 28.0

- **survival_by_pclass**: {1: 0.42105263157894735, 2: 0.3140794223826715, 3: 0.16784203102961917}

- **_detected_columns**: {'survived': '2urvived', 'sex': 'Sex', 'age': 'Age', 'pclass': 'Pclass'}




## Visualizations




### survival_by_sex

![](survival_by_sex.png)




### age_dist_by_survival

![](age_dist_by_survival.png)




## Brief findings




- Overall survival rate: 0.261.
- Survival by sex: 0=0.129, 1=0.500