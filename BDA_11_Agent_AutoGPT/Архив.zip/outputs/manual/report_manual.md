# Manual Analysis Report

## Steps executed
1. Load data
2. Convert types
3. Compute descriptive statistics
4. Create plots

## Key statistics
- **n_rows**: 1309
- **survival_rate**: 0.2612681436210848
- **survival_by_sex**: {0: 0.12930011862396204, 1: 0.5}

## Visualizations
![](survival_by_sex_manual.png)
![](age_dist_by_survival_manual.png)
